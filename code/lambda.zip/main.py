def handler():
    print("Uhh.. Put some backup code here please.")